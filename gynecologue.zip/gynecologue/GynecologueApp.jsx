import React, { useState, useEffect } from 'react';
import './gynecologue.css';

import Sidebar            from './components/Sidebar';
import Topbar             from './components/Topbar';
import RightPanel         from './components/RightPanel';
import Dashboard          from './pages/Dashboard';
import Patientes          from './pages/Patientes';
import DossierPatiente    from './pages/DossierPatiente';
import Consultations      from './pages/Consultations';
import NouvelleConsultation from './pages/NouvelleConsultation';
import Prescriptions      from './pages/Prescriptions';
import Examens            from './pages/Examens';
import RendezVous         from './pages/RendezVous';
import Notifications      from './pages/Notifications';
import Profil             from './pages/Profil';
import api                from './services/api';

export default function GynecologueApp() {
  const [activePage,    setActivePage]    = useState('dashboard');
  const [selectedId,    setSelectedId]    = useState(null);
  const [selectedId2,   setSelectedId2]   = useState(null);
  const [selectedPatienteId, setSelectedPatienteId] = useState(null);
  const [unreadCount,   setUnreadCount]   = useState(0);

  useEffect(() => {
    api.get('/notifications/non-lues')
      .then(res => {
        const data = res.data;
        setUnreadCount(Array.isArray(data) ? data.length : (data?.count ?? 0));
      }).catch(() => {});
  }, [activePage]);

  const handleNavigate = (page, id = null, id2 = null) => {
    setActivePage(page);
    setSelectedId(id ?? null);
    setSelectedId2(id2 ?? null);
    if (id && (page === 'dossier-patiente' || page === 'nouvelle-consultation' || page === 'nouvelle-prescription' || page === 'nouvel-examen')) {
      setSelectedPatienteId(id);
    }
  };

  const handleSelectPatiente = (id) => setSelectedPatienteId(id);

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':            return <Dashboard          onNavigate={handleNavigate} />;
      case 'patientes':            return <Patientes          onNavigate={handleNavigate} onSelectPatiente={handleSelectPatiente} />;
      case 'dossier-patiente':     return <DossierPatiente    onNavigate={handleNavigate} id={selectedId} />;
      case 'consultations':        return <Consultations      onNavigate={handleNavigate} />;
     case 'nouvelle-consultation': return <NouvelleConsultation onNavigate={handleNavigate} id={selectedId} consultationId={selectedId2} />;
      case 'prescriptions':        return <Prescriptions      onNavigate={handleNavigate} id={selectedId} />;
      case 'nouvelle-prescription':return <Prescriptions      onNavigate={handleNavigate} id={selectedId} />;
      case 'examens':              return <Examens            onNavigate={handleNavigate} id={selectedId} />;
      case 'nouvel-examen':        return <Examens            onNavigate={handleNavigate} id={selectedId} />;
      case 'rendez-vous':          return <RendezVous         onNavigate={handleNavigate} />;
      case 'nouveau-rdv':          return <RendezVous         onNavigate={handleNavigate} />;
      case 'notifications':        return <Notifications      />;
      case 'profil':               return <Profil             />;
      default:                     return <Dashboard          onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="gyn-shell">
      <Sidebar activePage={activePage} onNavigate={handleNavigate} unreadCount={unreadCount} />
      <div className="gyn-main">
        <Topbar onNavigate={handleNavigate} unreadCount={unreadCount} onSelectPatiente={handleSelectPatiente} />
        <div className="gyn-content-area">
          <div className="gyn-main-panel">
            {renderPage()}
          </div>
          <RightPanel patienteId={selectedPatienteId} onNavigate={handleNavigate} />
        </div>
      </div>
    </div>
  );
}
