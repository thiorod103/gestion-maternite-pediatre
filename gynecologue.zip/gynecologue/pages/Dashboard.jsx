import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatTime = (t) => t ? t.slice(0, 5) : '—';

export default function Dashboard({ onNavigate }) {
  const [stats, setStats] = useState({ 
    total_patientes: 0, 
    total_consultations: 0, 
    total_rdv: 0, 
    total_prescriptions: 0 
  });
  const [rdvJour, setRdvJour] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Récupération des statistiques spécifiques au gynécologue et des suivis récents
    Promise.all([
      api.get('/dashboard/gynecologue/stats'),
      api.get('/planifier-rv?statut=en_attente')
    ]).then(([statsRes, rdvRes]) => {
      setStats(statsRes.data);
      const dataRdv = Array.isArray(rdvRes.data) ? rdvRes.data : (rdvRes.data?.data ?? []);
      setRdvJour(dataRdv.slice(0, 5)); // On affiche les 5 dernières planifications
    })
    .catch(err => console.error("Erreur Dashboard:", err))
    .finally(() => setLoading(false));
  }, []);

  const now = new Date();
  const dateLabel = now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const prioriteBadge = (p) => {
    if (p === 'urgente') return { cls: 'urgent', label: '🟠 Urgente' };
    return { cls: 'normal', label: '🟢 Normale' };
  };

  if (loading) return (
    <div className="gyn-page-anim gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>
  );

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <div>
          <h2>Tableau de bord</h2>
          <div style={{ fontSize: 13, color: 'var(--gray)', marginTop: 4 }}>
            📅 {dateLabel.charAt(0).toUpperCase() + dateLabel.slice(1)}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn-primary btn-sm" onClick={() => onNavigate('nouvelle-consultation')}>＋ Consultation</button>
          <button className="btn-primary btn-sm" onClick={() => onNavigate('rendez-vous')}>📅 RDV</button>
        </div>
      </div>

      {/* Cartes de Statistiques */}
      <div className="gyn-stats">
        {[
          { label: 'Mes Patientes',      value: stats.total_patientes,     emoji: '👩',  bg: 'var(--rose-light)',  color: 'var(--rose)',   target: 'patientes' },
          { label: 'Mes Consultations',  value: stats.total_consultations, emoji: '🩺',  bg: 'var(--blue-light)',  color: 'var(--blue)',   target: 'consultations' },
          { label: 'Suivis à planifier', value: stats.total_rdv,           emoji: '📅',  bg: 'var(--amber-light)', color: 'var(--amber)',  target: null }, 
          { label: 'Mes Ordonnances',    value: stats.total_prescriptions, emoji: '💊',  bg: 'var(--green-light)', color: 'var(--green)',  target: 'prescriptions' },
        ].map(({ label, value, emoji, bg, color, target }) => (
          <div 
            key={label} 
            className="gyn-stat" 
            style={{ 
              borderLeft: `4px solid ${color}`, 
              cursor: target ? 'pointer' : 'default',
              transition: 'transform 0.2s ease'
            }}
            onClick={() => target && onNavigate(target)}
            onMouseEnter={(e) => target && (e.currentTarget.style.transform = 'translateY(-4px)')}
            onMouseLeave={(e) => target && (e.currentTarget.style.transform = 'translateY(0)')}
          >
            <div className="gyn-stat-icon" style={{ background: bg }}>{emoji}</div>
            <div>
              <div className="gyn-stat-value" style={{ color }}>{value}</div>
              <div className="gyn-stat-label">{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Liste des planifications récentes (Table Planifier_rv) */}
      <div className="gyn-card">
        <div className="gyn-card-head">
          <h3>📅 Planifications récentes (En attente secrétariat)</h3>
          <button className="btn-primary btn-sm" onClick={() => onNavigate('rendez-vous')}>Voir tout</button>
        </div>
        {rdvJour.length === 0 ? (
          <div className="gyn-center" style={{ padding: 40 }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>✅</div>
            <p style={{ color: 'var(--gray)' }}>Aucune planification en attente pour le moment.</p>
          </div>
        ) : (
          <table className="gyn-table">
            <thead>
              <tr>
                <th>Patiente</th>
                <th>Délai recommandé</th>
                <th>Motif</th>
                <th>Priorité</th>
              </tr>
            </thead>
            <tbody>
              {rdvJour.map(r => {
                const p = r.patiente ?? null;
                const nom = p ? `${p.prenom} ${p.nom}` : `Patiente ${r.id_patient}`;
                const pBadge = prioriteBadge(r.priorite);
                return (
                  <tr key={r.id}>
                    <td>
                      <div className="gyn-person-cell">
                        <div className="gyn-person-ava">👩</div>
                        <div>
                          <div className="gyn-person-name">{nom}</div>
                          <div className="gyn-person-id">P{String(r.id_patient).padStart(4,'0')}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ fontWeight: 700, color: 'var(--rose)' }}>{r.delai_recommande}</td>
                    <td style={{ fontSize: 12, color: 'var(--gray)' }}>{r.motif ?? '—'}</td>
                    <td><span className={`gyn-badge ${pBadge.cls}`}>{pBadge.label}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

Dashboard.propTypes = { onNavigate: PropTypes.func.isRequired };
