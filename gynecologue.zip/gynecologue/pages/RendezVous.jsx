import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

const getIdPersonnel = () => { 
  try { 
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.id_personnel || user.personnel?.id_personnel || 1; 
  } catch { return 1; } 
};

const statutBadge = (s) => {
  if (s === 'confirme')   return { cls: 'confirme', label: '✓ Confirmé'  };
  if (s === 'en_attente') return { cls: 'planifie', label: '⏳ En attente' };
  return { cls: 'normal', label: s };
};

const prioriteBadge = (p) => {
  if (p === 'urgente') return { cls: 'urgent', label: '🟠 Urgente' };
  return { cls: 'normal', label: '🟢 Normale' };
};

export default function RendezVous({ onNavigate }) {
  const [rdvs, setRdvs] = useState([]);
  const [patientes, setPatientes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filtre, setFiltre] = useState('tous');
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const [form, setForm] = useState({
    id_patient: '',
    delai_recommande: '',
    motif: '',
    priorite: 'normale',
  });

  // ── Charger les planifications (avec gestion pagination) ──
  const fetchRdvs = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/planifier-rv');
      // On extrait res.data.data si c'est paginé côté Laravel
      const data = res.data?.data ?? res.data ?? [];
      setRdvs(Array.isArray(data) ? data : []);
    } catch { 
      setRdvs([]); 
    } finally { 
      setLoading(false); 
    }
  }, []);

  useEffect(() => { fetchRdvs(); }, [fetchRdvs]);

  // ── Charger les patientes pour la Modal (avec gestion pagination) ──
  useEffect(() => {
    api.get('/mes-patientes').then(res => {
      const data = res.data?.data ?? res.data ?? [];
      setPatientes(Array.isArray(data) ? data : []);
    }).catch(() => setPatientes([]));
  }, []);

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSave = async () => {
    if (!form.id_patient || !form.delai_recommande) { 
      setError('Veuillez sélectionner une patiente et un délai.'); 
      return; 
    }
    setSaving(true); 
    setError(null);
    try {
      await api.post('/planifier-rv', { 
        id_patient: Number(form.id_patient), 
        id_personnel: getIdPersonnel(), 
        delai_recommande: form.delai_recommande, 
        motif: form.motif || null, 
        priorite: form.priorite,
        statut: 'en_attente'
      });
      setSuccess(true);
      setTimeout(() => { 
        setShowModal(false); 
        setSuccess(false); 
        setForm({ id_patient: '', delai_recommande: '', motif: '', priorite: 'normale' });
        fetchRdvs(); 
      }, 1500);
    } catch { 
      setError('Erreur lors de la planification.'); 
    } finally { 
      setSaving(false); 
    }
  };

  const filtered = filtre === 'tous' ? rdvs : rdvs.filter(r => r.statut === filtre);
  
  const inputStyle = { width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid var(--sand)', fontSize: 13, outline: 'none', background: '#fff' };
  const labelStyle = { fontSize: 12, fontWeight: 700, display: 'block', marginBottom: 5, color: 'var(--dark)' };

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>📅 Prédiction de Rendez-vous</h2>
        <button className="btn-primary btn-sm" onClick={() => { setShowModal(true); setError(null); setSuccess(false); }}>
          ＋ Planifier un suivi
        </button>
      </div>

      <div className="gyn-card">
        <div className="gyn-card-head">
            <h3>📋 Suivis à planifier par le secrétariat</h3>
            <div style={{ display: 'flex', gap: 10 }}>
                <select value={filtre} onChange={(e) => setFiltre(e.target.value)} style={{ ...inputStyle, width: 'auto', padding: '5px 10px' }}>
                    <option value="tous">Tous les statuts</option>
                    <option value="en_attente">⏳ En attente</option>
                    <option value="confirme">✓ Confirmés</option>
                </select>
            </div>
        </div>

        {loading && <div className="gyn-center" style={{padding: 40}}><div className="ico">⏳</div><p>Chargement des prédictions...</p></div>}
        
        {!loading && filtered.length === 0 && (
          <div className="gyn-center" style={{padding: 40}}>
            <div className="ico">📅</div>
            <p>Aucune planification en cours.</p>
          </div>
        )}

        {!loading && filtered.length > 0 && (
          <table className="gyn-table">
            <thead>
              <tr>
                <th>Patiente</th>
                <th>Délai recommandé</th>
                <th>Motif</th>
                <th>Priorité</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => {
                const p = r.patiente;
                const nom = p ? `${p.prenom} ${p.nom}` : `Patiente #${r.id_patient}`;
                const pB = prioriteBadge(r.priorite);
                const sB = statutBadge(r.statut);
                return (
                  <tr key={r.id_planification || r.id}>
                    <td>
                      <div className="gyn-person-cell">
                        <div className="gyn-person-ava">👩</div>
                        <div>
                          <div className="gyn-person-name">{nom}</div>
                          <div className="gyn-person-id">P{String(r.id_patient).padStart(4,'0')}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ fontWeight: 700, color: 'var(--rose)' }}>{r.delai_recommande}</td>
                    <td style={{ fontSize: 12, color: 'var(--gray)' }}>{r.motif ?? '—'}</td>
                    <td><span className={`gyn-badge ${pB.cls}`}>{pB.label}</span></td>
                    <td><span className={`gyn-badge ${sB.cls}`}>{sB.label}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal">
            <div className="gyn-modal-title">📅 Planifier un retour</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={labelStyle}>Patiente <span style={{ color: 'red' }}>*</span></label>
                <select name="id_patient" value={form.id_patient} onChange={handleChange} style={inputStyle}>
                  <option value="">— Sélectionner —</option>
                  {patientes.map(p => <option key={p.id_patient} value={p.id_patient}>{p.prenom} {p.nom}</option>)}
                </select>
              </div>
              
              <div>
                <label style={labelStyle}>Délai de retour recommandé <span style={{ color: 'red' }}>*</span></label>
                <select name="delai_recommande" value={form.delai_recommande} onChange={handleChange} style={inputStyle}>
                  <option value="">— Sélectionner le délai —</option>
                  <option value="1 semaine">Dans 1 semaine</option>
                  <option value="2 semaines">Dans 2 semaines</option>
                  <option value="1 mois">Dans 1 mois</option>
                  <option value="3 mois">Dans 3 mois</option>
                  <option value="Urgent">Urgent (ASAP)</option>
                </select>
              </div>

              <div>
                <label style={labelStyle}>Motif / Instructions</label>
                <input name="motif" value={form.motif} onChange={handleChange} placeholder="ex: Contrôle, résultat frottis..." style={inputStyle} />
              </div>

              <div>
                <label style={labelStyle}>Niveau de Priorité</label>
                <select name="priorite" value={form.priorite} onChange={handleChange} style={inputStyle}>
                  <option value="normale">🟢 Normale</option>
                  <option value="urgente">🟠 Urgente</option>
                </select>
              </div>

              {error && <div className="gyn-alert error">❌ {error}</div>}
              {success && <div className="gyn-alert success">✅ Planification enregistrée !</div>}
            </div>
            
            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(false)} disabled={saving}>Annuler</button>
              <button className="btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? '⏳...' : '✓ Confirmer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

RendezVous.propTypes = { onNavigate: PropTypes.func.isRequired };
