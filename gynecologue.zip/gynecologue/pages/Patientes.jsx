import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

const statutBadge = (s) => {
  if (s === 'active')   return { cls: 'normal',  label: '✓ Active'   };
  if (s === 'inactive') return { cls: 'planifie', label: '⏸ Inactive' };
  return                       { cls: 'annule',   label: '📦 Archivée' };
};

export default function Patientes({ onNavigate, onSelectPatiente }) {
  const [patientes, setPatientes] = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [page,      setPage]      = useState(1);
  const [total,     setTotal]     = useState(0);
  const perPage = 15;

  
  const fetchPatientes = useCallback(async (p, s) => {
    try {
      setLoading(true);
      const res  = await api.get(`/mes-patientes?page=${p}&per_page=${perPage}${s ? `&search=${encodeURIComponent(s)}` : ''}`);
      const data = res.data;
      setPatientes(data.data ?? data ?? []);
      setTotal(data.total ?? 0);
    } catch { setPatientes([]); } finally { setLoading(false); }
  }, []);


  useEffect(() => { fetchPatientes(page, search); }, [page, fetchPatientes]);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(1);
    fetchPatientes(1, e.target.value);
  };

  const totalPages = Math.ceil(total / perPage);

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>👩 Patientes</h2>
        <div style={{ fontSize: 13, color: 'var(--gray)' }}>{total} patiente{total > 1 ? 's' : ''}</div>
      </div>


      <div className="gyn-card">
        <div className="gyn-card-head">
          <h3>📋 Liste des patientes</h3>
        </div>

        {loading && <div className="gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>}

        {!loading && patientes.length === 0 && (
          <div className="gyn-center"><div className="ico">👩</div><p>Aucune patiente trouvée.</p></div>
        )}

        {!loading && patientes.length > 0 && (
          <>
            <table className="gyn-table">
              <thead>
                <tr>
                  <th>Patiente</th>
                  <th>Date naissance</th>
                  <th>Téléphone</th>
                  <th>Groupe sanguin</th>
                  <th>Statut</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {patientes.map(p => {
                  const age   = p.date_naissance ? Math.floor((new Date() - new Date(p.date_naissance)) / (365.25 * 24 * 3600 * 1000)) : null;
                  const badge = statutBadge(p.statut);
                  return (
                    <tr key={p.id_patient}>
                      <td>
                        <div className="gyn-person-cell">
                          <div className="gyn-person-ava">👩</div>
                          <div>
                            <div className="gyn-person-name">{p.prenom} {p.nom}</div>
                            <div className="gyn-person-id">P{String(p.id_patient).padStart(4,'0')}{age ? ` · ${age} ans` : ''}</div>
                          </div>
                        </div>
                      </td>
                      <td>{formatDate(p.date_naissance)}</td>
                      <td>{p.telephone ?? '—'}</td>
                      <td>
                        {p.groupe_sanguin
                          ? <span className="gyn-badge rose">{p.groupe_sanguin}</span>
                          : '—'}
                      </td>
                      <td><span className={`gyn-badge ${badge.cls}`}>{badge.label}</span></td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button
                            className="btn-primary btn-sm"
                            onClick={() => { onSelectPatiente(p.id_patient); onNavigate('dossier-patiente', p.id_patient); }}
                          >
                            👁️ Dossier
                          </button>
                          <button
                            className="btn-outline btn-sm"
                            onClick={() => { onSelectPatiente(p.id_patient); onNavigate('nouvelle-consultation', p.id_patient); }}
                          >
                            🩺
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Pagination */}
            {totalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10, padding: '16px 20px', borderTop: '1px solid var(--sand)' }}>
                <button className="btn-secondary btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Préc.</button>
                <span style={{ fontSize: 13, color: 'var(--gray)' }}>{page} / {totalPages}</span>
                <button className="btn-secondary btn-sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Suiv. →</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

Patientes.propTypes = { onNavigate: PropTypes.func.isRequired, onSelectPatiente: PropTypes.func.isRequired };
