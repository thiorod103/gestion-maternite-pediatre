import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';
const getIdPersonnel = () => { try { return JSON.parse(localStorage.getItem('user') || '{}')?.id_personnel ?? 1; } catch { return 1; } };
const parseError = (data) => { if (!data) return 'Erreur.'; if (data.errors) return Object.values(data.errors).flat().join('\n'); return data.message ?? 'Erreur.'; };

export default function Prescriptions({ onNavigate, id }) {
  const [prescriptions, setPrescriptions] = useState([]);
  const [patientes,     setPatientes]     = useState([]);
  const [consultations, setConsultations] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [showModal,     setShowModal]     = useState(!!id);
  const [saving,        setSaving]        = useState(false);
  const [error,         setError]         = useState(null);
  const [success,       setSuccess]       = useState(false);
  const [form, setForm] = useState({
    id_patient:        id ? String(id) : '',
    id_consultation:   '',
    medicaments:       '',
    posologie:         '',
    date_prescription: new Date().toISOString().slice(0, 10),
    date_fin:          '',
  });

  const fetchPrescriptions = useCallback(async () => {
    try {
      setLoading(true);
      const res  = await api.get('/prescriptions?per_page=20');
      const data = res.data;
      setPrescriptions(data.data ?? data ?? []);
    } catch { setPrescriptions([]); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchPrescriptions(); }, [fetchPrescriptions]);

  useEffect(() => {
    api.get('/patientes?per_page=100').then(res => {
      const data = res.data?.data ?? res.data ?? [];
      setPatientes(Array.isArray(data) ? data : []);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!form.id_patient) return;
    api.get(`/patientes/${form.id_patient}/consultations`).then(res => {
      const data = Array.isArray(res.data) ? res.data : (res.data?.data ?? []);
      setConsultations(data);
      if (data.length > 0) setForm(f => ({ ...f, id_consultation: String(data[data.length - 1].id_consultation) }));
    }).catch(() => {});
  }, [form.id_patient]);

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSave = async () => {
    if (!form.id_patient || !form.medicaments || !form.posologie || !form.date_prescription) {
      setError('Veuillez remplir tous les champs obligatoires.'); return;
    }
    setSaving(true); setError(null);
    try {
      await api.post('/prescriptions', {
        id_patient:        Number(form.id_patient),
        id_personnel:      getIdPersonnel(),
        id_consultation:   form.id_consultation ? Number(form.id_consultation) : null,
        medicaments:       form.medicaments,
        posologie:         form.posologie,
        date_prescription: form.date_prescription,
        date_fin:          form.date_fin || null,
      });
      setSuccess(true);
      setTimeout(() => { setShowModal(false); setSuccess(false); fetchPrescriptions(); }, 1500);
    } catch (err) { setError(parseError(err.response?.data)); } finally { setSaving(false); }
  };

  const inputStyle = { width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid var(--sand)', fontSize: 13, fontFamily: 'Nunito, sans-serif', outline: 'none', background: '#fff' };
  const labelStyle = { fontSize: 12, fontWeight: 700, display: 'block', marginBottom: 5, color: 'var(--dark)' };

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>💊 Prescriptions</h2>
        <button className="btn-primary btn-sm" onClick={() => setShowModal(true)}>＋ Nouvelle prescription</button>
      </div>

      <div className="gyn-card">
        <div className="gyn-card-head"><h3>📋 Historique des prescriptions</h3></div>

        {loading && <div className="gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>}
        {!loading && prescriptions.length === 0 && <div className="gyn-center"><div className="ico">💊</div><p>Aucune prescription.</p></div>}

        {!loading && prescriptions.length > 0 && (
          <table className="gyn-table">
            <thead>
              <tr><th>Patiente</th><th>Médicaments</th><th>Posologie</th><th>Date prescription</th><th>Date fin</th></tr>
            </thead>
            <tbody>
              {prescriptions.map(p => {
                const pat = p.patiente ?? null;
                const nom = pat ? `${pat.prenom} ${pat.nom}` : `P${String(p.id_patient).padStart(4,'0')}`;
                return (
                  <tr key={p.id_prescription}>
                    <td>
                      <div className="gyn-person-cell">
                        <div className="gyn-person-ava">👩</div>
                        <div><div className="gyn-person-name">{nom}</div><div className="gyn-person-id">P{String(p.id_patient).padStart(4,'0')}</div></div>
                      </div>
                    </td>
                    <td style={{ fontSize: 12, maxWidth: 160 }}>{p.medicaments}</td>
                    <td style={{ fontSize: 12, maxWidth: 160 }}>{p.posologie}</td>
                    <td>{formatDate(p.date_prescription)}</td>
                    <td>{formatDate(p.date_fin)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal" style={{ width: 560 }}>
            <div className="gyn-modal-title">💊 Nouvelle prescription</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={labelStyle}>Patiente <span style={{ color: 'red' }}>*</span></label>
                <select name="id_patient" value={form.id_patient} onChange={handleChange} style={inputStyle}>
                  <option value="">— Sélectionner —</option>
                  {patientes.map(p => <option key={p.id_patient} value={p.id_patient}>{p.prenom} {p.nom}</option>)}
                </select>
              </div>
              {consultations.length > 0 && (
                <div>
                  <label style={labelStyle}>Consultation liée</label>
                  <select name="id_consultation" value={form.id_consultation} onChange={handleChange} style={inputStyle}>
                    <option value="">— Sélectionner —</option>
                    {consultations.map(c => <option key={c.id_consultation} value={c.id_consultation}>{formatDate(c.date_consultation)} — {c.motif_consultation ?? '—'}</option>)}
                  </select>
                </div>
              )}
              <div>
                <label style={labelStyle}>Médicaments <span style={{ color: 'red' }}>*</span></label>
                <textarea name="medicaments" value={form.medicaments} onChange={handleChange} rows={2} placeholder="ex: Amoxicilline 500mg, Vitamine D..." style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div>
                <label style={labelStyle}>Posologie <span style={{ color: 'red' }}>*</span></label>
                <textarea name="posologie" value={form.posologie} onChange={handleChange} rows={2} placeholder="ex: 1 comprimé 3x/jour pendant 7 jours..." style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div className="gyn-form-grid">
                <div>
                  <label style={labelStyle}>Date prescription <span style={{ color: 'red' }}>*</span></label>
                  <input type="date" name="date_prescription" value={form.date_prescription} onChange={handleChange} style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Date fin</label>
                  <input type="date" name="date_fin" value={form.date_fin} onChange={handleChange} style={inputStyle} />
                </div>
              </div>
              {error   && <div className="gyn-alert error">❌ {error}</div>}
              {success && <div className="gyn-alert success">✅ Prescription enregistrée !</div>}
            </div>
            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(false)} disabled={saving}>Annuler</button>
              <button className="btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? '⏳ Enregistrement...' : '✓ Enregistrer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

Prescriptions.propTypes = { onNavigate: PropTypes.func.isRequired, id: PropTypes.number };
