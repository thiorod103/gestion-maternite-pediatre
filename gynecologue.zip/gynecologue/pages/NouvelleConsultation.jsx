import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const getIdPersonnel = () => {
  try { 
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.id_personnel || user.personnel?.id_personnel || 1; 
  } catch { return 1; }
};

const parseError = (data) => {
  if (!data) return 'Une erreur est survenue.';
  if (data.errors) return Object.values(data.errors).flat().join('\n');
  if (data.message) return data.message;
  return 'Une erreur est survenue.';
};

export default function NouvelleConsultation({ onNavigate, id, consultationId }) {
  const [patientes, setPatientes] = useState([]);
  const [loading,   setLoading]   = useState(false);
  const [success,   setSuccess]   = useState(false);
  const [error,     setError]     = useState(null);

  const isEdit = !!consultationId;

  const [form, setForm] = useState({
    id_patient:           id ? String(id) : '',
    date_consultation:    new Date().toISOString().slice(0, 10),
    motif_consultation:   '',
    poids:                '',
    temperature:          '',
    tension:              '',
    observation:          '',
    prochain_rdv:         '',
    date_derniere_regles: '',
    cycle_menstruel:      '',
    dernier_frottis:      '',
    examen_seins:         'non_effectue',
    diagnostic:           '',
    type_contraception:   '',
  });

  // ── Charger la liste des patientes (si création sans id direct) ──
  useEffect(() => {
    if (!id && !isEdit) {
      api.get('/patientes?per_page=100').then(res => {
        const data = res.data?.data ?? res.data ?? [];
        setPatientes(Array.isArray(data) ? data : []);
      }).catch(() => {});
    }
  }, [id, isEdit]);

  // ── Charger les données en mode édition ──
  useEffect(() => {
    if (!consultationId) return;
    setLoading(true);
    api.get(`/consultations/${consultationId}`)
      .then(res => {
        const c = res.data;
        const gyn = c.gynecologie || {};
        setForm({
          id_patient:           String(c.id_patient || ''),
          date_consultation:    c.date_consultation || '',
          motif_consultation:   c.motif_consultation || '',
          poids:                c.poids || '',
          temperature:          c.temperature || '',
          tension:              c.tension || '',
          observation:          c.observation || '',
          prochain_rdv:         c.prochain_rdv || '',
          date_derniere_regles: gyn.date_derniere_regles || '',
          cycle_menstruel:      gyn.cycle_menstruel || '',
          dernier_frottis:      gyn.dernier_frottis || '',
          examen_seins:         gyn.examen_seins || 'non_effectue',
          diagnostic:           gyn.diagnostic || '',
          type_contraception:   gyn.type_contraception || '',
        });
      })
      .catch(err => setError("Impossible de charger la consultation."))
      .finally(() => setLoading(false));
  }, [consultationId]);

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    if (!form.id_patient || !form.date_consultation || !form.motif_consultation) {
      setError('Veuillez remplir les champs obligatoires (*)');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      let currentId = consultationId;

      if (isEdit) {
        // ── MISE À JOUR ──
        await api.put(`/consultations/${consultationId}`, {
          date_consultation:  form.date_consultation,
          motif_consultation: form.motif_consultation,
          poids:              form.poids || null,
          temperature:        form.temperature || null,
          tension:            form.tension || null,
          observation:        form.observation || null,
          prochain_rdv:       form.prochain_rdv || null,
        });

        await api.put(`/consultations-gynecologie/${consultationId}`, {
          id_consultation:      consultationId,
          date_derniere_regles: form.date_derniere_regles || null,
          cycle_menstruel:      form.cycle_menstruel || null,
          dernier_frottis:      form.dernier_frottis || null,
          examen_seins:         form.examen_seins,
          diagnostic:           form.diagnostic || null,
          type_contraception:   form.type_contraception || null,
        });
      } else {
        // ── CRÉATION ──
        const res = await api.post('/consultations', {
          id_patient:         Number(form.id_patient),
          id_personnel:       getIdPersonnel(),
          date_consultation:  form.date_consultation,
          motif_consultation: form.motif_consultation,
          poids:              form.poids || null,
          temperature:        form.temperature || null,
          tension:            form.tension || null,
          observation:        form.observation || null,
          prochain_rdv:       form.prochain_rdv || null,
        });

        currentId = res.data?.id_consultation;

        if (currentId) {
          await api.post('/consultations-gynecologie', {
            id_consultation:      currentId,
            date_derniere_regles: form.date_derniere_regles || null,
            cycle_menstruel:      form.cycle_menstruel || null,
            dernier_frottis:      form.dernier_frottis || null,
            examen_seins:         form.examen_seins,
            diagnostic:           form.diagnostic || null,
            type_contraception:   form.type_contraception || null,
          });
        }
      }

      setSuccess(true);
      // Redirection après succès
      setTimeout(() => onNavigate(id ? 'dossier-patiente' : 'consultations', id || null), 1500);

    } catch (err) {
      setError(parseError(err.response?.data));
      setLoading(false); // On ne réactive le bouton qu'en cas d'erreur
    }
  };

  // Styles
  const inputStyle = { width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid var(--sand)', fontSize: 13, outline: 'none', background: '#fff' };
  const labelStyle = { fontSize: 12, fontWeight: 700, display: 'block', marginBottom: 5, color: 'var(--dark)' };

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="btn-secondary btn-sm" onClick={() => onNavigate(id ? 'dossier-patiente' : 'consultations', id || null)}>← Retour</button>
          <h2>{isEdit ? '✏️ Modifier la consultation' : '🩺 Nouvelle consultation'}</h2>
        </div>
      </div>

      <div className="gyn-card" style={{ maxWidth: 760, margin: '0 auto' }}>
        <div className="gyn-card-head">
          <h3>{isEdit ? '✏️ Modification' : '🩺 Consultation Gynécologique'}</h3>
        </div>
        
        <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
          
          {!id && !isEdit && (
            <div>
              <label style={labelStyle}>Patiente <span style={{ color: 'red' }}>*</span></label>
              <select name="id_patient" value={form.id_patient} onChange={handleChange} style={inputStyle}>
                <option value="">— Sélectionner une patiente —</option>
                {patientes.map(p => <option key={p.id_patient} value={p.id_patient}>{p.prenom} {p.nom}</option>)}
              </select>
            </div>
          )}

          <div className="gyn-form-grid">
            <div>
              <label style={labelStyle}>Date <span style={{ color: 'red' }}>*</span></label>
              <input type="date" name="date_consultation" value={form.date_consultation} onChange={handleChange} style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Prochain RDV</label>
              <input type="date" name="prochain_rdv" value={form.prochain_rdv} onChange={handleChange} style={inputStyle} />
            </div>
          </div>

          <div>
            <label style={labelStyle}>Motif <span style={{ color: 'red' }}>*</span></label>
            <input name="motif_consultation" value={form.motif_consultation} onChange={handleChange} style={inputStyle} placeholder="Motif de la visite..." />
          </div>

          <div className="gyn-section">
            <div className="gyn-section-title">📊 Constantes</div>
            <div className="gyn-form-grid">
              <input type="number" name="poids" placeholder="Poids (kg)" value={form.poids} onChange={handleChange} style={inputStyle} />
              <input type="number" name="temperature" placeholder="Temp. (°C)" value={form.temperature} onChange={handleChange} style={inputStyle} />
              <input name="tension" placeholder="Tension (ex: 12/8)" value={form.tension} onChange={handleChange} style={inputStyle} />
            </div>
          </div>

          <div className="gyn-section">
            <div className="gyn-section-title">🔬 Gynécologie</div>
            <div className="gyn-form-grid">
              <div>
                <label style={labelStyle}>Dernières règles</label>
                <input type="date" name="date_derniere_regles" value={form.date_derniere_regles} onChange={handleChange} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Cycle (jours)</label>
                <input type="number" name="cycle_menstruel" value={form.cycle_menstruel} onChange={handleChange} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Examen seins</label>
                <select name="examen_seins" value={form.examen_seins} onChange={handleChange} style={inputStyle}>
                  <option value="non_effectue">Non effectué</option>
                  <option value="normal">Normal</option>
                  <option value="anomalie_detectee">Anomalie</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label style={labelStyle}>Diagnostic</label>
            <textarea name="diagnostic" value={form.diagnostic} onChange={handleChange} rows={3} style={{...inputStyle, resize: 'vertical'}} placeholder="Conclusion médicale..." />
          </div>

          {error && <div className="gyn-alert error">❌ {error}</div>}
          {success && <div className="gyn-alert success">✅ Enregistré avec succès !</div>}

          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', borderTop: '1px solid var(--sand)', paddingTop: 20 }}>
            <button className="btn-secondary" onClick={() => onNavigate(id ? 'dossier-patiente' : 'consultations', id || null)} disabled={loading}>Annuler</button>
            <button className="btn-primary" onClick={handleSubmit} disabled={loading || !form.id_patient || !form.motif_consultation}>
              {loading ? '⏳ Traitement...' : '✓ Enregistrer'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

NouvelleConsultation.propTypes = { onNavigate: PropTypes.func.isRequired, id: PropTypes.number, consultationId: PropTypes.number };
