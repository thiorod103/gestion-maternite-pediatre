import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

export default function Consultations({ onNavigate }) {
  const [consultations, setConsultations] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [page,          setPage]          = useState(1);
  const [total,         setTotal]         = useState(0);

  const fetchConsultations = useCallback(async (p) => {
    try {
      setLoading(true);
      const res  = await api.get(`/consultations?page=${p}&per_page=15`);
      const data = res.data;
      setConsultations(data.data ?? []);
      setTotal(data.total ?? 0);
    } catch { setConsultations([]); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchConsultations(page); }, [page, fetchConsultations]);

  const totalPages = Math.ceil(total / 15);

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>🩺 Consultations</h2>
        <button className="btn-primary btn-sm" onClick={() => onNavigate('nouvelle-consultation')}>＋ Nouvelle consultation</button>
      </div>

      <div className="gyn-card">
        <div className="gyn-card-head">
          <h3>📋 Historique des consultations</h3>
          <span style={{ fontSize: 13, color: 'var(--gray)' }}>{total} consultation{total > 1 ? 's' : ''}</span>
        </div>

        {loading && <div className="gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>}

        {!loading && consultations.length === 0 && (
          <div className="gyn-center"><div className="ico">🩺</div><p>Aucune consultation.</p></div>
        )}

        {!loading && consultations.length > 0 && (
          <>
            <table className="gyn-table">
              <thead>
                <tr><th>Patiente</th><th>Date</th><th>Motif</th><th>Tension</th><th>Temp.</th><th>Poids</th><th>Action</th></tr>
              </thead>
              <tbody>
                {consultations.map(c => {
                  const p   = c.patiente ?? null;
                  const nom = p ? `${p.prenom} ${p.nom}` : `P${String(c.id_patient).padStart(4,'0')}`;
                  return (
                    <tr key={c.id_consultation}>
                      <td>
                        <div className="gyn-person-cell">
                          <div className="gyn-person-ava">👩</div>
                          <div>
                            <div className="gyn-person-name">{nom}</div>
                            <div className="gyn-person-id">P{String(c.id_patient).padStart(4,'0')}</div>
                          </div>
                        </div>
                      </td>
                      <td>{formatDate(c.date_consultation)}</td>
                      <td style={{ fontSize: 12, maxWidth: 160, color: 'var(--gray)' }}>{c.motif_consultation ?? '—'}</td>
                      <td>{c.tension     ?? '—'}</td>
                      <td>{c.temperature ? `${c.temperature}°C` : '—'}</td>
                      <td>{c.poids       ? `${c.poids} kg`      : '—'}</td>
                      <td>
                        <button
                          className="btn-primary btn-sm"
                          onClick={() => onNavigate('nouvelle-consultation', c.id_patient, c.id_consultation)}
                        >
                          ✏️ Modifier
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {totalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10, padding: '16px 20px', borderTop: '1px solid var(--sand)' }}>
                <button className="btn-secondary btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Préc.</button>
                <span style={{ fontSize: 13, color: 'var(--gray)' }}>{page} / {totalPages}</span>
                <button className="btn-secondary btn-sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Suiv. →</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

Consultations.propTypes = { onNavigate: PropTypes.func.isRequired };
