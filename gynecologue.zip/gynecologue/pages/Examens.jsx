import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';
const getIdPersonnel = () => { try { return JSON.parse(localStorage.getItem('user') || '{}')?.id_personnel ?? 1; } catch { return 1; } };

const TYPES_EXAMENS = ['Échographie', 'Frottis cervical', 'Bilan hormonal', 'NFS', 'Glycémie', 'Sérologie', 'Mammographie', 'Colposcopie', 'Biopsie', 'Autre'];

export default function Examens({ onNavigate, id }) {
  const [examens,   setExamens]   = useState([]);
  const [patientes, setPatientes] = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [showModal, setShowModal] = useState(!!id);
  const [modalType, setModalType] = useState('examen'); // 'examen' | 'resultat'
  const [selectedExamen, setSelectedExamen] = useState(null);
  const [saving,    setSaving]    = useState(false);
  const [error,     setError]     = useState(null);
  const [success,   setSuccess]   = useState(false);

  const [formExamen, setFormExamen] = useState({
    id_patient:  id ? String(id) : '',
    type_examen: '',
    date_examen: new Date().toISOString().slice(0, 10),
  });

  const [formResultat, setFormResultat] = useState({
    resultat:      '',
    date_resultat: new Date().toISOString().slice(0, 10),
  });

  const fetchExamens = useCallback(async () => {
    try {
      setLoading(true);
      const res  = await api.get('/examens');
      const data = Array.isArray(res.data) ? res.data : (res.data?.data ?? []);
      setExamens(data);
    } catch { setExamens([]); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchExamens(); }, [fetchExamens]);

  useEffect(() => {
    api.get('/patientes?per_page=100').then(res => {
      const data = res.data?.data ?? res.data ?? [];
      setPatientes(Array.isArray(data) ? data : []);
    }).catch(() => {});
  }, []);

  const handleSaveExamen = async () => {
    if (!formExamen.id_patient || !formExamen.type_examen) { setError('Champs obligatoires manquants.'); return; }
    setSaving(true); setError(null);
    try {
      await api.post('/examens', { id_patient: Number(formExamen.id_patient), id_personnel: getIdPersonnel(), type_examen: formExamen.type_examen, date_examen: formExamen.date_examen });
      setSuccess(true);
      setTimeout(() => { setShowModal(false); setSuccess(false); fetchExamens(); }, 1500);
    } catch { setError('Erreur lors de la création.'); } finally { setSaving(false); }
  };

  const handleSaveResultat = async () => {
    if (!formResultat.resultat) { setError('Veuillez saisir le résultat.'); return; }
    setSaving(true); setError(null);
    try {
      await api.post(`/examens/${selectedExamen.id_examen}/resultat`, formResultat);
      setSuccess(true);
      setTimeout(() => { setShowModal(false); setSuccess(false); fetchExamens(); }, 1500);
    } catch { setError('Erreur lors de l\'enregistrement.'); } finally { setSaving(false); }
  };

  const inputStyle = { width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid var(--sand)', fontSize: 13, fontFamily: 'Nunito, sans-serif', outline: 'none', background: '#fff' };
  const labelStyle = { fontSize: 12, fontWeight: 700, display: 'block', marginBottom: 5, color: 'var(--dark)' };

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>🔬 Examens</h2>
        <button className="btn-primary btn-sm" onClick={() => { setModalType('examen'); setShowModal(true); setError(null); setSuccess(false); }}>＋ Demander un examen</button>
      </div>

      <div className="gyn-card">
        <div className="gyn-card-head"><h3>📋 Liste des examens</h3></div>

        {loading && <div className="gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>}
        {!loading && examens.length === 0 && <div className="gyn-center"><div className="ico">🔬</div><p>Aucun examen.</p></div>}

        {!loading && examens.length > 0 && (
          <table className="gyn-table">
            <thead>
              <tr><th>Patiente</th><th>Type</th><th>Date</th><th>Résultat</th><th>Action</th></tr>
            </thead>
            <tbody>
              {examens.map(e => {
                const p   = e.patiente ?? null;
                const nom = p ? `${p.prenom} ${p.nom}` : `P${String(e.id_patient).padStart(4,'0')}`;
                const hasResult = e.resultats && e.resultats.length > 0;
                return (
                  <tr key={e.id_examen}>
                    <td>
                      <div className="gyn-person-cell">
                        <div className="gyn-person-ava">👩</div>
                        <div><div className="gyn-person-name">{nom}</div><div className="gyn-person-id">P{String(e.id_patient).padStart(4,'0')}</div></div>
                      </div>
                    </td>
                    <td style={{ fontWeight: 600 }}>{e.type_examen}</td>
                    <td>{formatDate(e.date_examen)}</td>
                    <td>
                      {hasResult
                        ? <span className="gyn-badge normal">✓ Disponible</span>
                        : <span className="gyn-badge planifie">⏳ En attente</span>}
                    </td>
                    <td>
                      {!hasResult && (
                        <button className="btn-outline btn-sm" onClick={() => { setSelectedExamen(e); setModalType('resultat'); setShowModal(true); setError(null); setSuccess(false); }}>
                          ＋ Résultat
                        </button>
                      )}
                      {hasResult && (
                        <span style={{ fontSize: 12, color: 'var(--gray)' }}>{e.resultats[0].resultat.slice(0, 40)}...</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal">
            <div className="gyn-modal-title">
              {modalType === 'examen' ? '🔬 Demander un examen' : `📋 Saisir résultat — ${selectedExamen?.type_examen}`}
            </div>

            {modalType === 'examen' ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div>
                  <label style={labelStyle}>Patiente <span style={{ color: 'red' }}>*</span></label>
                  <select value={formExamen.id_patient} onChange={e => setFormExamen(f => ({ ...f, id_patient: e.target.value }))} style={inputStyle}>
                    <option value="">— Sélectionner —</option>
                    {patientes.map(p => <option key={p.id_patient} value={p.id_patient}>{p.prenom} {p.nom}</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Type d&apos;examen <span style={{ color: 'red' }}>*</span></label>
                  <select value={formExamen.type_examen} onChange={e => setFormExamen(f => ({ ...f, type_examen: e.target.value }))} style={inputStyle}>
                    <option value="">— Sélectionner —</option>
                    {TYPES_EXAMENS.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Date de l&apos;examen</label>
                  <input type="date" value={formExamen.date_examen} onChange={e => setFormExamen(f => ({ ...f, date_examen: e.target.value }))} style={inputStyle} />
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div>
                  <label style={labelStyle}>Résultat <span style={{ color: 'red' }}>*</span></label>
                  <textarea value={formResultat.resultat} onChange={e => setFormResultat(f => ({ ...f, resultat: e.target.value }))} rows={4} placeholder="Décrivez le résultat de l'examen..." style={{ ...inputStyle, resize: 'vertical' }} />
                </div>
                <div>
                  <label style={labelStyle}>Date du résultat</label>
                  <input type="date" value={formResultat.date_resultat} onChange={e => setFormResultat(f => ({ ...f, date_resultat: e.target.value }))} style={inputStyle} />
                </div>
              </div>
            )}

            {error   && <div className="gyn-alert error" style={{ marginTop: 14 }}>❌ {error}</div>}
            {success && <div className="gyn-alert success" style={{ marginTop: 14 }}>✅ Enregistré avec succès !</div>}

            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(false)} disabled={saving}>Annuler</button>
              <button className="btn-primary" onClick={modalType === 'examen' ? handleSaveExamen : handleSaveResultat} disabled={saving}>
                {saving ? '⏳...' : '✓ Enregistrer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

Examens.propTypes = { onNavigate: PropTypes.func.isRequired, id: PropTypes.number };
