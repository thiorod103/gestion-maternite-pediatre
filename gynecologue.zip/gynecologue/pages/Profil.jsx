import React, { useState, useEffect } from 'react';
import api from '../services/api';

export default function Profil() {
  const [medecin,    setMedecin]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [editMode,   setEditMode]   = useState(false);
  const [newLogin,   setNewLogin]   = useState('');
  const [saving,     setSaving]     = useState(false);
  const [saveMsg,    setSaveMsg]    = useState(null);
  const [showMdp,    setShowMdp]    = useState(false);
  const [ancienMdp,  setAncienMdp]  = useState('');
  const [nouveauMdp, setNouveauMdp] = useState('');
  const [confirmMdp, setConfirmMdp] = useState('');
  const [mdpMsg,     setMdpMsg]     = useState(null);
  const [mdpLoading, setMdpLoading] = useState(false);

  useEffect(() => {
    api.get('/me').then(res => {
      const u = res.data;
      setMedecin({
        login:     u.login      ?? '—',
        prenom:    u.prenom     ?? '—',
        nom:       u.nom        ?? '—',
        role:      u.role_acces ?? '—',
        initiales: u.prenom && u.nom ? `${u.prenom[0]}${u.nom[0]}`.toUpperCase() : '??',
      });
      setNewLogin(u.login ?? '');
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const handleSaveLogin = async () => {
    if (!newLogin.trim()) return;
    setSaving(true); setSaveMsg(null);
    try {
      await api.put('/me', { login: newLogin });
      setMedecin(prev => ({ ...prev, login: newLogin }));
      setEditMode(false);
      setSaveMsg({ type: 'ok', text: '✓ Login mis à jour avec succès.' });
      setTimeout(() => setSaveMsg(null), 3000);
    } catch (err) {
      setSaveMsg({ type: 'err', text: err.response?.data?.message ?? 'Erreur.' });
    } finally { setSaving(false); }
  };

  const handleChangeMdp = async () => {
    if (!ancienMdp || !nouveauMdp || !confirmMdp) { setMdpMsg({ type: 'err', text: 'Tous les champs sont obligatoires.' }); return; }
    if (nouveauMdp !== confirmMdp) { setMdpMsg({ type: 'err', text: 'Les mots de passe ne correspondent pas.' }); return; }
    if (nouveauMdp.length < 6) { setMdpMsg({ type: 'err', text: 'Minimum 6 caractères.' }); return; }
    setMdpLoading(true); setMdpMsg(null);
    try {
      await api.put('/me/password', { ancien_mdp: ancienMdp, nouveau_mdp: nouveauMdp });
      setMdpMsg({ type: 'ok', text: '✓ Mot de passe modifié avec succès.' });
      setAncienMdp(''); setNouveauMdp(''); setConfirmMdp('');
      setShowMdp(false);
      setTimeout(() => setMdpMsg(null), 3000);
    } catch (err) {
      setMdpMsg({ type: 'err', text: err.response?.data?.message ?? 'Erreur.' });
    } finally { setMdpLoading(false); }
  };

  if (loading) return <div className="gyn-page-anim gyn-center"><div className="ico">⏳</div><p>Chargement...</p></div>;

  const inputStyle = { width: '100%', padding: '9px 12px', border: '1.5px solid var(--sand)', borderRadius: 9, fontSize: 13, fontFamily: 'Nunito, sans-serif', background: 'var(--bg)', outline: 'none', color: 'var(--dark)' };
  const rowStyle   = { display: 'flex', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--bg)', gap: 10 };
  const msgStyle   = (type) => ({ padding: '10px 14px', borderRadius: 8, fontSize: 13, marginBottom: 14, background: type === 'ok' ? 'var(--green-light)' : 'var(--red-light)', borderLeft: `4px solid ${type === 'ok' ? 'var(--green)' : 'var(--red)'}`, color: type === 'ok' ? 'var(--green)' : 'var(--red)' });

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <h2>👤 Profil</h2>
        <button className="btn-secondary btn-sm" onClick={() => { setEditMode(!editMode); setSaveMsg(null); }}>
          {editMode ? '✕ Annuler' : '✏️ Modifier'}
        </button>
      </div>

      {/* Bannière */}
      <div style={{ background: 'linear-gradient(135deg, var(--rose-light), #fff)', border: '1.5px solid var(--rose-border)', borderRadius: 16, padding: '24px 28px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 20 }}>
        <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, var(--rose), var(--rose-2))', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 800 }}>
          {medecin.initiales}
        </div>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{medecin.prenom} {medecin.nom}</div>
          <div style={{ fontSize: 13, color: 'var(--rose)', fontWeight: 600, marginTop: 4 }}>Gynécologue · {medecin.login}</div>
          <span style={{ display: 'inline-block', marginTop: 6, background: 'var(--rose-light)', color: 'var(--rose)', border: '1px solid var(--rose-border)', fontSize: 11, fontWeight: 700, padding: '2px 10px', borderRadius: 20 }}>
            🔒 {medecin.role}
          </span>
        </div>
      </div>

      {saveMsg && <div style={msgStyle(saveMsg.type)}>{saveMsg.text}</div>}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Informations */}
        <div className="gyn-card">
          <div className="gyn-card-head"><h3>👤 Informations du compte</h3></div>
          <div style={{ padding: '4px 20px 8px' }}>
            <div style={rowStyle}>
              <span>👤</span>
              <span style={{ color: 'var(--gray)', fontSize: 13 }}>Login</span>
              {!editMode ? (
                <span style={{ marginLeft: 'auto', fontWeight: 600 }}>{medecin.login}</span>
              ) : (
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
                  <input style={{ ...inputStyle, maxWidth: 200 }} value={newLogin} onChange={e => setNewLogin(e.target.value)} />
                  <button className="btn-primary btn-sm" onClick={handleSaveLogin} disabled={saving}>{saving ? '⏳' : '✓'}</button>
                </div>
              )}
            </div>
            <div style={rowStyle}>
              <span>🏷️</span>
              <span style={{ color: 'var(--gray)', fontSize: 13 }}>Nom complet</span>
              <span style={{ marginLeft: 'auto', fontWeight: 600 }}>{medecin.prenom} {medecin.nom}</span>
            </div>
            <div style={{ ...rowStyle, borderBottom: 'none' }}>
              <span>🎭</span>
              <span style={{ color: 'var(--gray)', fontSize: 13 }}>Rôle</span>
              <span style={{ marginLeft: 'auto' }}>
                <span style={{ background: 'var(--rose-light)', color: 'var(--rose)', border: '1px solid var(--rose-border)', fontSize: 11, fontWeight: 700, padding: '2px 10px', borderRadius: 20 }}>{medecin.role}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Sécurité */}
        <div className="gyn-card">
          <div className="gyn-card-head"><h3>🔐 Sécurité</h3></div>
          <div style={{ padding: '4px 20px 8px' }}>
            <div style={{ ...rowStyle, flexDirection: 'column', alignItems: 'flex-start' }}>
              <div style={{ display: 'flex', width: '100%', alignItems: 'center' }}>
                <span style={{ marginRight: 10 }}>🔒</span>
                <span style={{ color: 'var(--gray)', fontSize: 13 }}>Mot de passe</span>
                <span style={{ marginLeft: 'auto', color: 'var(--rose)', cursor: 'pointer', fontSize: 13, fontWeight: 600 }} onClick={() => { setShowMdp(!showMdp); setMdpMsg(null); }}>
                  {showMdp ? 'Annuler ✕' : 'Modifier ›'}
                </span>
              </div>
              {showMdp && (
                <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10, marginTop: 10 }}>
                  {mdpMsg && <div style={msgStyle(mdpMsg.type)}>{mdpMsg.text}</div>}
                  <input type="password" style={inputStyle} placeholder="Ancien mot de passe" value={ancienMdp} onChange={e => setAncienMdp(e.target.value)} />
                  <input type="password" style={inputStyle} placeholder="Nouveau mot de passe" value={nouveauMdp} onChange={e => setNouveauMdp(e.target.value)} />
                  <input type="password" style={inputStyle} placeholder="Confirmer le mot de passe" value={confirmMdp} onChange={e => setConfirmMdp(e.target.value)} />
                  <button className="btn-primary" onClick={handleChangeMdp} disabled={mdpLoading}>
                    {mdpLoading ? '⏳ Modification...' : '🔒 Changer le mot de passe'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
