import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

const graviteBadge = (g) => {
  if (g === 'critique') return { cls: 'critique', label: '🔴 Critique' };
  if (g === 'grave')    return { cls: 'urgent',   label: '🟠 Grave'    };
  if (g === 'modere')   return { cls: 'modere',   label: '🟡 Modéré'   };
  return                       { cls: 'faible',   label: '🟢 Faible'   };
};

export default function DossierPatiente({ onNavigate, id }) {
  const [patiente,      setPatiente]      = useState(null);
  const [grossesses,    setGrossesses]    = useState([]);
  const [antecedents,   setAntecedents]   = useState([]);
  const [consultations, setConsultations] = useState([]);
  const [hospitalisations, setHospitalisations] = useState([]);
  const [examens,       setExamens]       = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [activeTab,     setActiveTab]     = useState('infos');

  // --- ÉTATS POUR LES MODALES ---
  const [showModal, setShowModal] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  // --- FORMULAIRES SYNCHRONISÉS AVEC TA BASE ---
  const [formAnt, setFormAnt] = useState({ categorie: 'Médical', description: '', gravite: 'faible' });
  const [formGro, setFormGro] = useState({ date_debut: '', semaines_amenorrhee: '', type_grossesse: 'simple', statut: 'en_cours', nombre_foetus: 1 });
  const [formHos, setFormHos] = useState({ 
    date_admission: new Date().toISOString().split('T')[0], // Changé ici
    motif: '', 
    statut: 'active', 
  });


  const fetchData = useCallback(() => {
    if (!id) return;
    setLoading(true);
    const ex = (res) => (Array.isArray(res.data) ? res.data : (res.data?.data ?? []));

    Promise.all([
      api.get(`/patientes/${id}`),
      api.get(`/patientes/${id}/grossesses`).catch(() => ({ data: [] })),
      api.get(`/patientes/${id}/antecedents`).catch(() => ({ data: [] })),
      api.get(`/patientes/${id}/consultations`).catch(() => ({ data: [] })),
      api.get(`/patientes/${id}/hospitalisations`).catch(() => ({ data: [] })),
      api.get(`/examens?id_patient=${id}`).catch(() => ({ data: [] })),
    ]).then(([pRes, gRes, aRes, cRes, hRes, eRes]) => {
      setPatiente(pRes.data);
      setGrossesses(ex(gRes));
      setAntecedents(ex(aRes));
      setConsultations(ex(cRes));
      setHospitalisations(ex(hRes));
      
      const allEx = ex(eRes);
      setExamens(allEx.filter(x => !x.id_patient || String(x.id_patient) === String(id)));
      
    }).catch(() => {}).finally(() => setLoading(false));
  }, [id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSave = async (type, data) => {
  setIsSaving(true);
  try {
    const endpoints = { ant: '/antecedents', gro: '/grossesses', hos: '/hospitalisations' };
    
    // On prépare les données à envoyer
    let payload = { ...data, id_patient: id };

    // Sécurité spécifique pour l'hospitalisation
    if (type === 'hos') {
      payload = {
        id_patient: id,
        date_admission: data.date_admission || new Date().toISOString().split('T')[0],
        motif: data.motif,
        statut: 'active'
      };
    }

    await api.post(endpoints[type], payload);
    setShowModal(null);
    fetchData(); // Rafraîchir les tableaux
  } catch (err) { 
    console.error(err.response?.data);
    alert(err.response?.data?.message || "Erreur lors de l'enregistrement"); 
  } finally { 
    setIsSaving(false); 
  }
};


  const deleteItem = async (type, itemId) => {
    if (!window.confirm("Supprimer cet élément ?")) return;
    try {
      await api.delete(`/${type}/${itemId}`);
      fetchData();
    } catch { alert("Erreur lors de la suppression"); }
  };

  if (loading) return <div className="gyn-page-anim gyn-center">⏳ Chargement...</div>;
  if (!patiente) return <div className="gyn-page-anim gyn-center">❌ Dossier introuvable</div>;

  const age = patiente.date_naissance ? Math.floor((new Date() - new Date(patiente.date_naissance)) / (365.25 * 24 * 3600 * 1000)) : null;

  return (
    <div className="gyn-page-anim">
      <div className="gyn-page-title">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="btn-secondary btn-sm" onClick={() => onNavigate('patientes')}>← Retour</button>
          <h2>Dossier — {patiente.prenom} {patiente.nom}</h2>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-primary btn-sm" onClick={() => onNavigate('nouvelle-consultation', id)}>＋ Consultation</button>
          <button className="btn-outline btn-sm" onClick={() => onNavigate('nouvelle-prescription', id)}>💊 Prescrire</button>
        </div>
      </div>

      <div style={{ background: 'linear-gradient(135deg, var(--rose-light), #fff)', border: '1.5px solid var(--rose-border)', borderRadius: 16, padding: '20px 24px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 20 }}>
        <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--rose)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, fontWeight: 800 }}>
          {patiente.prenom[0]}{patiente.nom[0]}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{patiente.prenom} {patiente.nom}</div>
          <div style={{ fontSize: 13, color: 'var(--gray)', marginTop: 4 }}>
            P{String(patiente.id_patient).padStart(4,'0')} · {age ? `${age} ans` : '—'} · {patiente.groupe_sanguin}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <span className="gyn-badge rose">{patiente.statut}</span>
          {patiente.groupe_sanguin && <span className="gyn-badge normal">{patiente.groupe_sanguin}</span>}
        </div>
      </div>

      <div className="gyn-tabs">
        {[
          { k: 'infos', l: '👩 Infos', c: null },
          { k: 'antecedents', l: '📋 Antécédents', c: antecedents.length },
          { k: 'consultations', l: '🩺 Consultations', c: consultations.length },
          { k: 'grossesses', l: '🤰 Grossesses', c: grossesses.length },
          { k: 'hospitalisations', l: '🏥 Hospit.', c: hospitalisations.length },
          { k: 'examens', l: '🔬 Examens', c: examens.length },
        ].map(t => (
          <div key={t.k} className={`gyn-tab${activeTab === t.k ? ' active' : ''}`} onClick={() => setActiveTab(t.k)}>
            {t.l} {t.c !== null && <span style={{marginLeft:5, fontSize:10, background:'var(--rose)', color:'#fff', padding:'1px 5px', borderRadius:10}}>{t.c}</span>}
          </div>
        ))}
      </div>

      {activeTab === 'infos' && (
        <div className="gyn-card">
          <div className="gyn-card-head"><h3>👩 Informations générales</h3></div>
          <div style={{ padding: '16px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[
              { label: 'Nom complet',    value: `${patiente.prenom} ${patiente.nom}` },
              { label: 'Date naissance', value: formatDate(patiente.date_naissance)  },
              { label: 'Téléphone',      value: patiente.telephone ?? '—'            },
              { label: 'Adresse',        value: patiente.adresse   ?? '—'            },
              { label: 'Situation',      value: patiente.situation_matrimoniale ?? '—' },
              { label: 'Groupe sanguin', value: patiente.groupe_sanguin ?? '—'       },
            ].map(({ label, value }) => (
              <div key={label} style={{ background: 'var(--bg)', borderRadius: 8, padding: '12px 16px' }}>
                <div style={{ fontSize: 11, color: 'var(--gray)', fontWeight: 600, marginBottom: 4 }}>{label}</div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'antecedents' && (
        <div className="gyn-card">
          <div className="gyn-card-head" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>📋 Antécédents</h3>
            <button className="btn-primary btn-sm" onClick={() => setShowModal('ant')}>＋ Ajouter</button>
          </div>
          <table className="gyn-table">
            <thead><tr><th>Catégorie</th><th>Description</th><th>Gravité</th><th>Action</th></tr></thead>
            <tbody>
              {antecedents.map(a => (
                <tr key={a.id_antecedent}>
                  <td><strong>{a.categorie}</strong></td>
                  <td>{a.description}</td>
                  <td><span className={`gyn-badge ${graviteBadge(a.gravite).cls}`}>{graviteBadge(a.gravite).label}</span></td>
                  <td><button onClick={() => deleteItem('antecedents', a.id_antecedent)} style={{border:'none', background:'none', cursor:'pointer'}}>🗑️</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'consultations' && (
        <div className="gyn-card">
          <div className="gyn-card-head"><h3>🩺 Historique Médical</h3></div>
          <table className="gyn-table">
            <thead><tr><th>Date</th><th>Diagnostic</th><th>Motif</th><th>Constantes</th></tr></thead>
            <tbody>
              {consultations.map(c => (
                <tr key={c.id_consultation}>
                  <td>{formatDate(c.date_consultation)}</td>
                  <td style={{ color: 'var(--rose)', fontWeight: 600 }}>{c.gynecologie?.diagnostic || c.consultation_gynecologie?.diagnostic || '—'}</td>
                  <td>{c.motif_consultation || '—'}</td>
                  <td style={{fontSize:11}}>{c.poids && `${c.poids}kg`} {c.tension && `· ${c.tension}`}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'grossesses' && (
        <div className="gyn-card">
          <div className="gyn-card-head" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>🤰 Grossesses</h3>
            <button className="btn-primary btn-sm" onClick={() => setShowModal('gro')}>＋ Déclarer</button>
          </div>
          <table className="gyn-table">
            <thead><tr><th>Début</th><th>SA</th><th>Statut</th><th>Action</th></tr></thead>
            <tbody>
              {grossesses.map(g => (
                <tr key={g.id_grossesse}>
                  <td>{formatDate(g.date_debut)}</td>
                  <td>{g.semaines_amenorrhee} SA</td>
                  <td><span className="gyn-badge rose">{g.statut}</span></td>
                  <td><button onClick={() => deleteItem('grossesses', g.id_grossesse)} style={{border:'none', background:'none', cursor:'pointer'}}>🗑️</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'hospitalisations' && (
        <div className="gyn-card">
          <div className="gyn-card-head" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>🏥 Hospitalisations</h3>
            <button className="btn-primary btn-sm" onClick={() => setShowModal('hos')}>＋ Hospitaliser</button>
          </div>
          <table className="gyn-table">
            <thead><tr><th>Date Entrée</th><th>Motif</th><th>Statut</th><th>Action</th></tr></thead>
            <tbody>
              {hospitalisations.map(h => (
                <tr key={h.id_hospitalisation}>
                  <td>{formatDate(h.date_entree || h.date_admission)}</td>
                  <td>{h.motif}</td>
                  <td><span className="gyn-badge planifie">{h.statut}</span></td>
                  <td><button onClick={() => deleteItem('hospitalisations', h.id_hospitalisation)} style={{border:'none', background:'none', cursor:'pointer'}}>🗑️</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'examens' && (
        <div className="gyn-card">
          <div className="gyn-card-head"><h3>🔬 Résultats d&apos;Examens</h3></div>
          <table className="gyn-table">
            <thead><tr><th>Type</th><th>Date</th><th>Résultat</th></tr></thead>
            <tbody>
              {examens.map(e => (
                <tr key={e.id_examen}>
                  <td><strong>{e.type_examen}</strong></td>
                  <td>{formatDate(e.date_examen)}</td>
                  <td>{e.resultat || (e.resultats && e.resultats[0]?.resultat) || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {/* --- MODALES --- */}

      {/* MODALE ANTÉCÉDENTS (AJOUTÉE ICI) */}
      {showModal === 'ant' && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal" style={{ maxWidth: 400 }}>
            <div className="gyn-modal-title">📋 Nouveau antécédent</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '10px 0' }}>
              <label style={{ fontSize: 11, fontWeight: 700 }}>Catégorie</label>
              <select className="gyn-input" value={formAnt.categorie} onChange={e => setFormAnt({ ...formAnt, categorie: e.target.value })}>
                <option value="Médical">Médical</option>
                <option value="Chirurgical">Chirurgical</option>
                <option value="Gynéco-obstétrique">Gynéco-obstétrique</option>
                <option value="Familial">Familial</option>
                <option value="Allergie">Allergie</option>
              </select>
              <label style={{ fontSize: 11, fontWeight: 700 }}>Description</label>
              <textarea className="gyn-input" placeholder="Description..." value={formAnt.description} onChange={e => setFormAnt({ ...formAnt, description: e.target.value })} style={{ minHeight: 80 }} />
              <label style={{ fontSize: 11, fontWeight: 700 }}>Gravité</label>
              <select className="gyn-input" value={formAnt.gravite} onChange={e => setFormAnt({ ...formAnt, gravite: e.target.value })}>
                <option value="faible">🟢 Faible</option>
                <option value="modere">🟡 Modéré</option>
                <option value="grave">🟠 Grave</option>
                <option value="critique">🔴 Critique</option>
              </select>
            </div>
            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="btn-primary" onClick={() => handleSave('ant', formAnt)} disabled={isSaving}>
                {isSaving ? '⏳...' : '✓ Enregistrer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE GROSSESSE */}
      {showModal === 'gro' && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal" style={{ maxWidth: 400 }}>
            <div className="gyn-modal-title">🤰 Nouvelle Grossesse</div>
            <label style={{ fontSize: 11, fontWeight: 700 }}>Date début</label>
            <input type="date" className="gyn-input" style={{ width: '100%', marginBottom: 10 }} value={formGro.date_debut} onChange={e => setFormGro({ ...formGro, date_debut: e.target.value })} />
            <label style={{ fontSize: 11, fontWeight: 700 }}>SA (Semaines)</label>
            <input type="number" className="gyn-input" style={{ width: '100%', marginBottom: 10 }} placeholder="SA (Semaines)" value={formGro.semaines_amenorrhee} onChange={e => setFormGro({ ...formGro, semaines_amenorrhee: e.target.value })} />
            <label style={{ fontSize: 11, fontWeight: 700 }}>Statut actuel</label>
            <select className="gyn-input" style={{ width: '100%', marginBottom: 10 }} value={formGro.statut} onChange={e => setFormGro({ ...formGro, statut: e.target.value })}>
              <option value="en_cours">En cours</option>
              <option value="terminee">Terminée</option>
              <option value="avortement">Avortement</option>
              <option value="fausse_couche">Fausse couche</option>
            </select>
            <label style={{ fontSize: 11, fontWeight: 700 }}>Type de grossesse</label>
            <select className="gyn-input" style={{ width: '100%', marginBottom: 10 }} value={formGro.type_grossesse} onChange={e => setFormGro({ ...formGro, type_grossesse: e.target.value })}>
              <option value="simple">Simple</option>
              <option value="gemellaire">Gémellaire</option>
              <option value="multiple">Multiple</option>
            </select>
            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="btn-primary" onClick={() => handleSave('gro', formGro)} disabled={isSaving}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE HOSPITALISATION (UNE SEULE FOIS, PROPRE) */}
      {showModal === 'hos' && (
        <div className="gyn-modal-overlay">
          <div className="gyn-modal">
            <div className="gyn-modal-title">🏥 Hospitaliser</div>
            <label style={{ fontSize: 11, fontWeight: 700 }}>Date d&apos;admission</label>
            <input type="date" className="gyn-input" style={{ width: '100%', marginBottom: 10 }} value={formHos.date_admission} onChange={e => setFormHos({ ...formHos, date_admission: e.target.value })} />
            <label style={{ fontSize: 11, fontWeight: 700 }}>Motif</label>
            <textarea className="gyn-input" style={{ width: '100%', marginBottom: 10, minHeight: 80 }} placeholder="Motif..." value={formHos.motif} onChange={e => setFormHos({ ...formHos, motif: e.target.value })} />
            <div className="gyn-modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="btn-primary" onClick={() => handleSave('hos', formHos)} disabled={isSaving}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

DossierPatiente.propTypes = { onNavigate: PropTypes.func.isRequired, id: PropTypes.number };
