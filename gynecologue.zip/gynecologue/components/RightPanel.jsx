import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

const formatDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR') : '—';

export default function RightPanel({ patienteId, onNavigate }) {
  const [patiente,    setPatiente]    = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [grossesses,  setGrossesses]  = useState([]);
  const [antecedents, setAntecedents] = useState([]);

  useEffect(() => {
    if (!patienteId) { setPatiente(null); return; }
    setLoading(true);
    Promise.all([
      api.get(`/patientes/${patienteId}`),
      api.get(`/patientes/${patienteId}/grossesses`).catch(() => ({ data: [] })),
      api.get(`/patientes/${patienteId}/antecedents`).catch(() => ({ data: [] })),
    ]).then(([pRes, gRes, aRes]) => {
      setPatiente(pRes.data);
      setGrossesses(Array.isArray(gRes.data) ? gRes.data : (gRes.data?.data ?? []));
      setAntecedents(Array.isArray(aRes.data) ? aRes.data : (aRes.data?.data ?? []));
    }).catch(() => {}).finally(() => setLoading(false));
  }, [patienteId]);

  if (!patienteId) return (
    <div className="gyn-right-panel">
      <div className="gyn-rp-title">Vue rapide</div>
      <div style={{ textAlign: 'center', padding: '40px 10px', color: 'var(--gray)' }}>
        <div style={{ fontSize: 36, marginBottom: 10 }}>👩</div>
        <div style={{ fontSize: 13, fontWeight: 600 }}>Sélectionnez une patiente</div>
        <div style={{ fontSize: 12, marginTop: 4 }}>pour voir son dossier complet</div>
      </div>
    </div>
  );

  if (loading) return (
    <div className="gyn-right-panel">
      <div className="gyn-rp-title">Vue rapide</div>
      <div style={{ textAlign: 'center', padding: 40 }}>⏳</div>
    </div>
  );

  if (!patiente) return null;

  const age = patiente.date_naissance
    ? Math.floor((new Date() - new Date(patiente.date_naissance)) / (365.25 * 24 * 3600 * 1000))
    : null;

  const derniereGrossesse = grossesses[0] ?? null;
  const antecedentsCritiques = antecedents.filter(a => a.gravite === 'critique' || a.gravite === 'grave');

  return (
    <div className="gyn-right-panel">
      <div className="gyn-rp-title">Vue rapide</div>

      {/* Fiche patiente */}
      <div className="gyn-rp-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--rose)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14 }}>
            {patiente.prenom[0]}{patiente.nom[0]}
          </div>
          <div>
            <div className="gyn-rp-name">{patiente.prenom} {patiente.nom}</div>
            <div className="gyn-rp-sub">P{String(patiente.id_patient).padStart(4,'0')} · {age ? `${age} ans` : '—'}</div>
          </div>
        </div>
        <div className="gyn-rp-row"><span className="label">Téléphone</span><span className="value">{patiente.telephone ?? '—'}</span></div>
        <div className="gyn-rp-row"><span className="label">Groupe sanguin</span><span className="value">{patiente.groupe_sanguin ?? '—'}</span></div>
        <div className="gyn-rp-row"><span className="label">Situation</span><span className="value">{patiente.situation_matrimoniale ?? '—'}</span></div>
      </div>

      {/* Alerte antécédents critiques */}
      {antecedentsCritiques.length > 0 && (
        <div style={{ background: 'var(--red-light)', border: '1px solid #fca5a5', borderRadius: 10, padding: '10px 14px', marginBottom: 14, fontSize: 12, color: 'var(--red)', fontWeight: 600 }}>
          ⚠️ {antecedentsCritiques.length} antécédent{antecedentsCritiques.length > 1 ? 's' : ''} grave{antecedentsCritiques.length > 1 ? 's' : ''}
        </div>
      )}

      {/* Dernière grossesse */}
      {derniereGrossesse && (
        <div style={{ marginBottom: 14 }}>
          <div className="gyn-rp-title" style={{ marginBottom: 8 }}>🤰 Dernière grossesse</div>
          <div style={{ background: '#fff', border: '1px solid var(--sand)', borderRadius: 10, padding: '12px 14px' }}>
            <div className="gyn-rp-row"><span className="label">Date début</span><span className="value">{formatDate(derniereGrossesse.date_debut)}</span></div>
            <div className="gyn-rp-row"><span className="label">Statut</span><span className="value">{derniereGrossesse.statut ?? '—'}</span></div>
            <div className="gyn-rp-row" style={{ borderBottom: 'none' }}><span className="label">SA</span><span className="value">{derniereGrossesse.semaines_amenorrhee ?? '—'} SA</span></div>
          </div>
        </div>
      )}

      {/* Actions rapides */}
      <div className="gyn-rp-title" style={{ marginBottom: 8 }}>Actions rapides</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <button className="btn-primary btn-sm" style={{ justifyContent: 'center' }} onClick={() => onNavigate('nouvelle-consultation', patiente.id_patient)}>
          ＋ Nouvelle consultation
        </button>
        <button className="btn-outline btn-sm" style={{ textAlign: 'center' }} onClick={() => onNavigate('nouvelle-prescription', patiente.id_patient)}>
          💊 Prescrire
        </button>
        <button className="btn-outline btn-sm" style={{ textAlign: 'center' }} onClick={() => onNavigate('nouvel-examen', patiente.id_patient)}>
          🔬 Demander examen
        </button>
      </div>
    </div>
  );
}

RightPanel.propTypes = { patienteId: PropTypes.number, onNavigate: PropTypes.func.isRequired };
