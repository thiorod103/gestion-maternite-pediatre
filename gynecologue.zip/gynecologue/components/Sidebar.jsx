import React from 'react';
import PropTypes from 'prop-types';
import api from '../services/api'; // Import de l'API pour le logout

const NAV = [
  { key: 'dashboard',     label: 'Dashboard',        emoji: '🏠' },
  { key: 'patientes',     label: 'Patientes',         emoji: '👩' },
  { key: 'consultations', label: 'Consultations',     emoji: '🩺' },
  { key: 'prescriptions', label: 'Prescriptions',     emoji: '💊' },
  { key: 'examens',       label: 'Examens',           emoji: '🔬' },
  { key: 'rendez-vous',   label: 'Rendez-vous',       emoji: '📅' },
  { key: 'notifications', label: 'Notifications',     emoji: '🔔' },
  { key: 'profil',        label: 'Profil',            emoji: '👤' },
];

export default function Sidebar({ activePage, onNavigate, unreadCount }) {
  const user = (() => { try { return JSON.parse(localStorage.getItem('user') || '{}'); } catch { return {}; } })();
  const initials = `${(user.prenom ?? 'G')[0]}${(user.nom ?? 'Y')[0]}`.toUpperCase();

  // Fonction de déconnexion immédiate
  const handleLogout = async () => {
    try {
      await api.post('/logout'); // Invalide le token côté Laravel
    } catch (error) {
      console.error("Erreur déconnexion:", error);
    } finally {
      // Nettoyage local dans tous les cas
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      // Redirection brute pour réinitialiser l'état de l'app
      window.location.href = '/login';
    }
  };

  return (
    <aside className="gyn-sidebar">
      <div className="gyn-sidebar-logo">
        <div style={{ fontSize: 22, marginBottom: 6 }}>🏥</div>
        <div className="hospital-name">Maternité Hôpital<br />Régional Thiès</div>
        <div className="hospital-dept">Gynécologie</div>
      </div>

      <div className="gyn-user-block">
        <div className="gyn-user-avatar">{initials}</div>
        <div>
          <div className="gyn-user-name">{user.prenom ?? ''} {user.nom ?? ''}</div>
          <div className="gyn-user-login">{user.login ?? ''}</div>
          <div className="gyn-user-role">Gynécologue</div>
        </div>
      </div>

      <nav className="gyn-nav" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <div className="gyn-nav-label">Navigation</div>
        
        <div style={{ flex: 1 }}>
          {NAV.map(({ key, label, emoji }) => (
            <div
              key={key}
              className={`gyn-nav-item${activePage === key ? ' active' : ''}`}
              onClick={() => onNavigate(key)}
            >
              <span>{emoji}</span>
              <span style={{ flex: 1 }}>{label}</span>
              {key === 'notifications' && unreadCount > 0 && (
                <span style={{ background: 'var(--rose)', color: '#fff', fontSize: 9, fontWeight: 800, padding: '1px 6px', borderRadius: 10, minWidth: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {unreadCount}
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Bouton de Déconnexion en bas */}
        <div 
          className="gyn-nav-item logout" 
          onClick={handleLogout}
          style={{ marginTop: 'auto', color: '#e11d48', fontWeight: 700, borderTop: '1.5px solid var(--sand)', paddingTop: 15 }}
        >
          <span>⎋</span>
          <span>Se deconnecter</span>
        </div>
      </nav>
    </aside>
  );
}

Sidebar.propTypes = { 
  activePage: PropTypes.string.isRequired, 
  onNavigate: PropTypes.func.isRequired, 
  unreadCount: PropTypes.number 
};
