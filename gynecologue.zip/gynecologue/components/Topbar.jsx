import React, { useState, useEffect, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import api from '../services/api';

export default function Topbar({ onNavigate, unreadCount, onSelectPatiente }) {
  const [user,      setUser]      = useState({ nom: '...', prenom: '...' });
  const [query,     setQuery]     = useState('');
  const [resultats, setResultats] = useState([]);
  const [searching, setSearching] = useState(false);
  const [showDrop,  setShowDrop]  = useState(false);
  const searchRef = useRef(null);
  const timerRef  = useRef(null);

  useEffect(() => { 
    api.get('/me').then(res => setUser(res.data)).catch(() => {}); 
  }, []);

  useEffect(() => {
    const handleClick = (e) => { 
      if (searchRef.current && !searchRef.current.contains(e.target)) setShowDrop(false); 
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSearch = useCallback((value) => {
    setQuery(value);
    clearTimeout(timerRef.current);

    if (value.length < 2) { 
      setResultats([]); 
      setShowDrop(false); 
      return; 
    }

    timerRef.current = setTimeout(async () => {
      try {
        setSearching(true);
        // Utilisation de la route filtrée pour le gynécologue
        const res  = await api.get(`/mes-patientes?search=${encodeURIComponent(value)}&per_page=6`);
        // On extrait les données de la pagination Laravel
        const data = res.data?.data ?? res.data ?? [];
        setResultats(Array.isArray(data) ? data : []);
        setShowDrop(true);
      } catch { 
        setResultats([]); 
      } finally { 
        setSearching(false); 
      }
    }, 300);
  }, []);

  const handleSelect = (p) => {
    setQuery(''); 
    setResultats([]); 
    setShowDrop(false);
    
    // On sélectionne la patiente et on navigue directement vers son dossier
    if (onSelectPatiente) onSelectPatiente(p.id_patient);
    onNavigate('dossier-patiente', p.id_patient);
  };

  const initials  = `${(user.prenom ?? 'G')[0]}${(user.nom ?? 'Y')[0]}`.toUpperCase();
  const nomComplet = `${user.prenom ?? ''} ${user.nom ?? ''}`.trim();

  return (
    <header className="gyn-topbar">
      <div ref={searchRef} style={{ position: 'relative' }}>
        <div className="gyn-search">
          <span style={{ color: 'var(--rose)' }}>{searching ? '⏳' : '🔍'}</span>
          <input 
            value={query} 
            onChange={e => handleSearch(e.target.value)} 
            placeholder="Rechercher une de mes patientes..." 
            onFocus={() => resultats.length > 0 && setShowDrop(true)} 
          />
          {query && (
            <span 
              style={{ cursor: 'pointer', color: 'var(--gray)', fontSize: 12 }} 
              onClick={() => { setQuery(''); setResultats([]); setShowDrop(false); }}
            >
              ✕
            </span>
          )}
        </div>

        {showDrop && resultats.length > 0 && (
          <div style={{ 
            position: 'absolute', 
            top: 'calc(100% + 8px)', 
            left: 0, 
            width: 380, 
            background: '#fff', 
            borderRadius: 12, 
            border: '1.5px solid var(--sand)', 
            boxShadow: '0 8px 24px rgba(0,0,0,0.12)', 
            zIndex: 200, 
            overflow: 'hidden' 
          }}>
            <div style={{ padding: '8px 16px', fontSize: 10, fontWeight: 700, color: 'var(--gray)', textTransform: 'uppercase', letterSpacing: '0.08em', background: 'var(--bg)' }}>
              👩 Mes Patientes
            </div>
            {resultats.map(p => (
              <div 
                key={p.id_patient} 
                onClick={() => handleSelect(p)}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 16px', cursor: 'pointer', borderBottom: '1px solid var(--bg)' }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--rose-light)'}
                onMouseLeave={e => e.currentTarget.style.background = '#fff'}
              >
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--rose-light)', border: '1.5px solid var(--rose-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>
                  👩
                </div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--dark)' }}>{p.prenom} {p.nom}</div>
                  <div style={{ fontSize: 11, color: 'var(--gray)' }}>
                    P{String(p.id_patient).padStart(4,'0')} · {p.telephone ?? '—'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="gyn-topbar-right">
        <div className="gyn-notif-btn" onClick={() => onNavigate('notifications')}>
          🔔
          {unreadCount > 0 && <span className="gyn-notif-badge">{unreadCount}</span>}
        </div>
        
        <div onClick={() => onNavigate('profil')} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 12px 6px 6px', borderRadius: 24, background: 'var(--rose-light)', border: '1.5px solid var(--rose-border)', cursor: 'pointer' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--rose)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 800 }}>
            {initials}
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--dark)', lineHeight: 1.3 }}>{nomComplet}</div>
            <div style={{ fontSize: 10, color: 'var(--rose)', fontWeight: 600 }}>gynécologue</div>
          </div>
          <span style={{ fontSize: 10, color: 'var(--gray)' }}>▾</span>
        </div>
      </div>
    </header>
  );
}

Topbar.propTypes = { 
  onNavigate: PropTypes.func.isRequired, 
  unreadCount: PropTypes.number, 
  onSelectPatiente: PropTypes.func 
};
